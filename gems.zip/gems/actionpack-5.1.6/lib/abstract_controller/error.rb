module AbstractController
  class Error < StandardError #:nodoc:
  end
end
